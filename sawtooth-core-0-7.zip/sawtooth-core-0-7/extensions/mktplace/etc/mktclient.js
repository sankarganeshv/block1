{
    "LedgerURL" : "http://localhost:8800/",
    "TokenURL" : "http://localhost:7800/",

    ## participant
    "ParticipantName" : "player1",

    ## key file
    "KeyFile" : "{home}/keys/{name}.wif"
}
