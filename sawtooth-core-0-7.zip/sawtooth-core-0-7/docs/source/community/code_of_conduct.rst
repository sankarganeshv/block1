
Code of Conduct
===============

When participating, please be respectful and courteous.

Sawtooth Lake uses the `Hyperledger Project Code of Conduct
<https://github.com/hyperledger/hyperledger/wiki/Hyperledger-Project-Code-of-Conduct>`_.

