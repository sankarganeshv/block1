*******************
Join the Discussion
*******************

.. _slack:

Slack
=====

Slack is the place to go for real-time chat about everything from quick help to
involved discussion.

You can find us on the Hyperledger Project's Slack instance, in the #sawtooth
channel.

If you need an invite, go to the `Hyperledger Project Slack Invitition
Request Page <https://slack.hyperledger.org/>`_.

The slack instance is at:

    `Hyperledger Project Slack <http://hyperledgerproject.slack.com/>`_
    *#sawtooth*

Mailing Lists
=============

The Sawtooth Lake mailing list is hosted by the Hyperledger Project:

   `hyperledger-stl Mailing List <http://lists.hyperledger.org/mailman/listinfo/hyperledger-stl>`_

