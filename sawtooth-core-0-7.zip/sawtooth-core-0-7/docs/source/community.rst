*********
Community
*********

Welcome to the Sawtooth Lake community!

For help topics, we recommend joining us on Slack (link below).

.. toctree::
   :maxdepth: 2

   community/join_the_discussion
   community/issue_tracking
   community/contributing
   community/code_of_conduct

